import { TypeFilterPipe } from './type-filters.pipe';

describe('TypeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TypeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
