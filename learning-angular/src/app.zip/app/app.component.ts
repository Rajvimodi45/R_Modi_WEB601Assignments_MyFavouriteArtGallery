import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'learning-angular';
}


console.log ("First console log");
setTimeout(function(){ console.log("Second console log"); }, 0);
Promise.resolve().then(function(){ console.log("Third console log"); });
console.log("Fourth console log");