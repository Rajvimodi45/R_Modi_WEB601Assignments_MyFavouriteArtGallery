import { Directive,ElementRef,HostListener, Input } from '@angular/core';

@Directive({
  selector: '[typeHoverAffect]'
})
export class HoverAffectDirective {

  constructor(public elementRef:ElementRef) { }
  @Input('type-affect') typeAffect:any;


  @HostListener('mouseenter') onMouseEnter() {

    this.elementRef.nativeElement.classList.add(this.typeAffect);
    
  
 }

  @HostListener('mouseleave') onMouseLeave() {
    this.elementRef.nativeElement.classList.remove(this.typeAffect);
}

}
